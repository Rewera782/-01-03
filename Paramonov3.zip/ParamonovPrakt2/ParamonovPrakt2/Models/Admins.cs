﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamonovPrakt2.Models
{

    public class ADMIN
    {
        public int AdminId { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public bool isAdmin { get; set; }
    }
}
